# sidekick-serverless
##1. clone之后先安装dependency：
<pre><code>npm install
</code></pre>

##2. 安装serverless
<pre><code>npm install -g serverless@0.5.6
</code></pre>

##3. 如果需要的话，用自己的aws账号init serverless的project，以便用自己的账户权限deploy等等。
